CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TYPE app_role AS ENUM ('user','driver','admin');
CREATE TYPE driver_approval AS ENUM ('pending','approved','rejected','blocked');
CREATE TYPE ride_status AS ENUM ('requested','accepted','arrived','in_progress','completed','cancelled','no_driver');
CREATE TYPE payment_method AS ENUM ('cash','upi','razorpay','wallet');
CREATE TYPE payment_status AS ENUM ('pending','authorized','paid','failed','refunded');

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  phone_e164 VARCHAR(16) UNIQUE NOT NULL,
  display_name VARCHAR(100) NOT NULL DEFAULT 'GaonCab user',
  photo_url TEXT,
  role app_role NOT NULL DEFAULT 'user',
  village_id UUID,
  phone_verified_at TIMESTAMPTZ,
  is_blocked BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE villages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(100) NOT NULL,
  district VARCHAR(100) NOT NULL DEFAULT 'Lakhimpur Kheri',
  state VARCHAR(100) NOT NULL DEFAULT 'Uttar Pradesh',
  center_lat NUMERIC(9,6),
  center_lng NUMERIC(9,6),
  active BOOLEAN NOT NULL DEFAULT true,
  UNIQUE(name,district,state)
);
ALTER TABLE users ADD CONSTRAINT users_village_fk FOREIGN KEY (village_id) REFERENCES villages(id);

CREATE TABLE driver_profiles (
  user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  approval_status driver_approval NOT NULL DEFAULT 'pending',
  rating NUMERIC(2,1) NOT NULL DEFAULT 5.0 CHECK (rating BETWEEN 0 AND 5),
  total_trips INTEGER NOT NULL DEFAULT 0 CHECK (total_trips >= 0),
  is_online BOOLEAN NOT NULL DEFAULT false,
  last_latitude NUMERIC(9,6),
  last_longitude NUMERIC(9,6),
  preferred_villages UUID[] NOT NULL DEFAULT '{}',
  preferred_rate_per_km NUMERIC(8,2),
  bank_account_last4 CHAR(4),
  upi_id VARCHAR(100),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE driver_documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  driver_id UUID NOT NULL REFERENCES driver_profiles(user_id) ON DELETE CASCADE,
  document_type VARCHAR(30) NOT NULL CHECK (document_type IN ('identity','driving_license','rc','insurance','vehicle_photo','bank_proof')),
  storage_key TEXT NOT NULL,
  verification_status driver_approval NOT NULL DEFAULT 'pending',
  expires_at DATE,
  reviewed_by UUID REFERENCES users(id),
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE vehicles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  driver_id UUID NOT NULL REFERENCES driver_profiles(user_id) ON DELETE CASCADE,
  vehicle_type VARCHAR(20) NOT NULL CHECK (vehicle_type IN ('bike','auto','erickshaw','sedan','suv','pickup','tractor')),
  registration_number VARCHAR(20) UNIQUE NOT NULL,
  make_model VARCHAR(100),
  passenger_capacity SMALLINT NOT NULL DEFAULT 3,
  active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE fare_rules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  village_id UUID REFERENCES villages(id),
  vehicle_type VARCHAR(20) NOT NULL,
  base_fare NUMERIC(8,2) NOT NULL CHECK (base_fare >= 0),
  per_km NUMERIC(8,2) NOT NULL CHECK (per_km >= 0),
  per_minute_wait NUMERIC(8,2) NOT NULL DEFAULT 0 CHECK (per_minute_wait >= 0),
  night_multiplier NUMERIC(4,2) NOT NULL DEFAULT 1 CHECK (night_multiplier >= 1),
  minimum_fare NUMERIC(8,2) NOT NULL DEFAULT 0,
  active BOOLEAN NOT NULL DEFAULT true,
  updated_by UUID REFERENCES users(id),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE NULLS NOT DISTINCT (village_id,vehicle_type)
);

CREATE TABLE rides (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  passenger_id UUID REFERENCES users(id),
  driver_id UUID REFERENCES driver_profiles(user_id),
  pickup_label VARCHAR(180) NOT NULL,
  pickup_lat NUMERIC(9,6),
  pickup_lng NUMERIC(9,6),
  drop_label VARCHAR(180) NOT NULL,
  drop_lat NUMERIC(9,6),
  drop_lng NUMERIC(9,6),
  vehicle_type VARCHAR(20) NOT NULL,
  estimated_fare NUMERIC(10,2) NOT NULL CHECK (estimated_fare >= 0),
  final_fare NUMERIC(10,2),
  payment_method payment_method NOT NULL DEFAULT 'cash',
  payment_status payment_status NOT NULL DEFAULT 'pending',
  status ride_status NOT NULL DEFAULT 'requested',
  start_otp_hash TEXT,
  scheduled_at TIMESTAMPTZ,
  accepted_at TIMESTAMPTZ,
  started_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  cancelled_at TIMESTAMPTZ,
  cancellation_reason VARCHAR(300),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX rides_passenger_created_idx ON rides(passenger_id,created_at DESC);
CREATE INDEX rides_driver_created_idx ON rides(driver_id,created_at DESC);
CREATE INDEX rides_status_created_idx ON rides(status,created_at DESC);

CREATE TABLE payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ride_id UUID NOT NULL REFERENCES rides(id),
  provider VARCHAR(30) NOT NULL,
  provider_order_id VARCHAR(150),
  provider_payment_id VARCHAR(150),
  amount NUMERIC(10,2) NOT NULL CHECK (amount >= 0),
  currency CHAR(3) NOT NULL DEFAULT 'INR',
  status payment_status NOT NULL DEFAULT 'pending',
  idempotency_key VARCHAR(100) UNIQUE,
  provider_payload JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ride_id UUID NOT NULL UNIQUE REFERENCES rides(id),
  passenger_id UUID NOT NULL REFERENCES users(id),
  driver_id UUID NOT NULL REFERENCES driver_profiles(user_id),
  rating SMALLINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment VARCHAR(1000),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE coupons (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code VARCHAR(30) UNIQUE NOT NULL,
  description VARCHAR(200),
  discount_type VARCHAR(10) NOT NULL CHECK (discount_type IN ('flat','percent')),
  discount_value NUMERIC(8,2) NOT NULL CHECK (discount_value > 0),
  max_discount NUMERIC(8,2),
  min_fare NUMERIC(8,2) NOT NULL DEFAULT 0,
  starts_at TIMESTAMPTZ,
  ends_at TIMESTAMPTZ,
  usage_limit INTEGER,
  active BOOLEAN NOT NULL DEFAULT true
);

CREATE TABLE trusted_contacts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name VARCHAR(100) NOT NULL,
  phone_e164 VARCHAR(16) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  channel VARCHAR(20) NOT NULL CHECK (channel IN ('in_app','sms','push','whatsapp')),
  title VARCHAR(150) NOT NULL,
  body TEXT NOT NULL,
  sent_at TIMESTAMPTZ,
  read_at TIMESTAMPTZ,
  provider_reference VARCHAR(150),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE support_tickets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  ride_id UUID REFERENCES rides(id),
  category VARCHAR(50) NOT NULL,
  description TEXT NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'open' CHECK (status IN ('open','in_progress','resolved','closed')),
  assigned_to UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE coupons_redemptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  coupon_id UUID NOT NULL REFERENCES coupons(id),
  user_id UUID NOT NULL REFERENCES users(id),
  ride_id UUID REFERENCES rides(id),
  redeemed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(coupon_id,user_id,ride_id)
);

CREATE TABLE audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_id UUID REFERENCES users(id),
  action VARCHAR(100) NOT NULL,
  entity_type VARCHAR(60) NOT NULL,
  entity_id UUID,
  metadata JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE app_settings (
  key VARCHAR(100) PRIMARY KEY,
  value JSONB NOT NULL,
  updated_by UUID REFERENCES users(id),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
