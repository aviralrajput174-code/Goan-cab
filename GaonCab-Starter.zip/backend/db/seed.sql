INSERT INTO villages(name,district,state,center_lat,center_lng) VALUES
('Timra','Lakhimpur Kheri','Uttar Pradesh',27.950000,80.780000),
('Tamilabadi','Lakhimpur Kheri','Uttar Pradesh',27.955000,80.790000),
('Seetaram','Lakhimpur Kheri','Uttar Pradesh',27.945000,80.770000),
('Bazar Tola','Lakhimpur Kheri','Uttar Pradesh',27.960000,80.785000),
('Naya Gaon','Lakhimpur Kheri','Uttar Pradesh',27.940000,80.800000)
ON CONFLICT(name,district,state) DO NOTHING;

INSERT INTO fare_rules(vehicle_type,base_fare,per_km,per_minute_wait,night_multiplier,minimum_fare) VALUES
('bike',15,8,1,1.2,20),('auto',25,14,2,1.2,35),('erickshaw',20,12,1,1.15,30),
('sedan',50,18,3,1.25,70),('pickup',80,24,3,1.2,100),('tractor',100,28,4,1.2,120)
ON CONFLICT DO NOTHING;

-- Ten synthetic demo driver accounts. These are placeholders, not real identities or verified drivers.
INSERT INTO users(phone_e164,display_name,role,village_id,phone_verified_at)
SELECT '+9199000000'||lpad(n::text,2,'0'), name, 'driver',
  (SELECT id FROM villages ORDER BY name LIMIT 1 OFFSET ((n-1)%5)), now()
FROM (VALUES (1,'Demo Driver 01'),(2,'Demo Driver 02'),(3,'Demo Driver 03'),(4,'Demo Driver 04'),(5,'Demo Driver 05'),
(6,'Demo Driver 06'),(7,'Demo Driver 07'),(8,'Demo Driver 08'),(9,'Demo Driver 09'),(10,'Demo Driver 10')) AS d(n,name)
ON CONFLICT(phone_e164) DO NOTHING;

INSERT INTO driver_profiles(user_id,approval_status,rating,is_online,last_latitude,last_longitude,preferred_rate_per_km)
SELECT id, CASE WHEN display_name IN ('Demo Driver 01','Demo Driver 02','Demo Driver 03') THEN 'approved'::driver_approval ELSE 'pending'::driver_approval END,
  (4.2 + ((right(phone_e164,2)::int % 8)::numeric/10)), right(phone_e164,2)::int % 2 = 0,
  27.95 + (right(phone_e164,2)::int * 0.001), 80.78 + (right(phone_e164,2)::int * 0.001), 12
FROM users WHERE role='driver'
ON CONFLICT(user_id) DO NOTHING;

INSERT INTO vehicles(driver_id,vehicle_type,registration_number,make_model,passenger_capacity)
SELECT u.id,
  (ARRAY['auto','bike','erickshaw','sedan','pickup','tractor','auto','bike','erickshaw','sedan'])[right(u.phone_e164,2)::int]::text,
  'UP32DEMO'||right(u.phone_e164,2), 'Demo vehicle', 3
FROM users u WHERE u.role='driver'
ON CONFLICT(registration_number) DO NOTHING;

INSERT INTO app_settings(key,value) VALUES
('commission_percent','{"value":10}'::jsonb),
('support_phone','{"value":""}'::jsonb),
('sos_enabled','{"value":false}'::jsonb),
('default_language','{"value":"en"}'::jsonb)
ON CONFLICT(key) DO NOTHING;
