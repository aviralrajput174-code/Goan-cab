import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import pg from 'pg';
import { z } from 'zod';

const app = express();
const port = Number(process.env.PORT || 4000);
const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false });
app.disable('x-powered-by');
app.use(helmet());
app.use(cors({ origin: (process.env.FRONTEND_ORIGIN || 'http://localhost:5173').split(',').map(s=>s.trim()), credentials: true }));
app.use(express.json({ limit: '100kb' }));
app.use('/api', rateLimit({ windowMs: 60_000, limit: 120, standardHeaders: 'draft-7', legacyHeaders: false }));

const rideSchema = z.object({
  pickup: z.string().trim().min(2).max(180),
  drop: z.string().trim().min(2).max(180),
  vehicleType: z.enum(['bike','auto','erickshaw','sedan','pickup','tractor']),
  estimatedFare: z.number().int().min(0).max(100000),
  paymentMethod: z.enum(['cash','upi','razorpay','wallet']).default('cash'),
  scheduledAt: z.string().datetime().nullable().optional()
});

app.get('/api/health', async (_req,res) => {
  let database = 'not_configured';
  try { await pool.query('SELECT 1'); database = 'ok'; } catch { database = 'unavailable'; }
  res.status(database === 'ok' ? 200 : 503).json({ ok: database === 'ok', service: 'gaon-cab-api', database });
});

app.get('/api/villages', async (_req,res,next) => {
  try { const result = await pool.query('SELECT id, name, district, state FROM villages WHERE active=true ORDER BY name'); res.json(result.rows); }
  catch (e) { next(e); }
});

app.get('/api/drivers/nearby', async (req,res,next) => {
  const lat = Number(req.query.lat), lng = Number(req.query.lng);
  if (!Number.isFinite(lat) || !Number.isFinite(lng) || Math.abs(lat)>90 || Math.abs(lng)>180) return res.status(400).json({error:'Valid lat and lng are required'});
  try {
    const type = req.query.vehicleType ? String(req.query.vehicleType) : null;
    const result = await pool.query(`
      SELECT u.id, u.display_name, dp.rating, dp.last_latitude, dp.last_longitude, v.vehicle_type, v.registration_number
      FROM driver_profiles dp JOIN users u ON u.id=dp.user_id
      JOIN vehicles v ON v.driver_id=dp.user_id AND v.active=true
      WHERE dp.approval_status='approved' AND dp.is_online=true
        AND ($3::text IS NULL OR v.vehicle_type=$3)
        AND dp.last_latitude IS NOT NULL AND dp.last_longitude IS NOT NULL
      ORDER BY ((dp.last_latitude-$1)^2 + (dp.last_longitude-$2)^2) ASC LIMIT 30`, [lat,lng,type]);
    res.json(result.rows);
  } catch(e) { next(e); }
});

app.get('/api/rides', async (req,res,next) => {
  const userId = req.query.userId;
  if (!userId) return res.status(400).json({error:'userId is required'});
  try {
    const result = await pool.query(`SELECT id, pickup_label, drop_label, vehicle_type, estimated_fare, payment_method, status, created_at FROM rides WHERE passenger_id=$1 ORDER BY created_at DESC LIMIT 100`,[userId]);
    res.json(result.rows);
  } catch(e) { next(e); }
});

app.post('/api/rides', async (req,res,next) => {
  const parsed = rideSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({error:'Invalid ride request', details:parsed.error.flatten()});
  // Auth is intentionally not faked: production must require a verified session and derive passenger_id from it.
  if (process.env.NODE_ENV === 'production') return res.status(501).json({error:'Authentication provider/session middleware must be configured before accepting production rides'});
  try {
    const {pickup,drop,vehicleType,estimatedFare,paymentMethod,scheduledAt} = parsed.data;
    const result = await pool.query(`INSERT INTO rides (pickup_label,drop_label,vehicle_type,estimated_fare,payment_method,status,scheduled_at,passenger_id)
      VALUES ($1,$2,$3,$4,$5,'requested',$6,(SELECT id FROM users WHERE role='user' ORDER BY created_at LIMIT 1)) RETURNING id,pickup_label,drop_label,vehicle_type,estimated_fare,payment_method,status,created_at`,
      [pickup,drop,vehicleType,estimatedFare,paymentMethod,scheduledAt || null]);
    res.status(201).json(result.rows[0]);
  } catch(e) { next(e); }
});

app.patch('/api/rides/:id/status', async (req,res,next) => {
  const schema = z.object({status:z.enum(['requested','accepted','arrived','in_progress','completed','cancelled'])});
  const parsed=schema.safeParse(req.body);
  if(!parsed.success) return res.status(400).json({error:'Invalid status'});
  if(process.env.NODE_ENV==='production') return res.status(501).json({error:'Admin auth middleware must be configured before status changes'});
  try {
    const result=await pool.query('UPDATE rides SET status=$1, updated_at=now() WHERE id=$2 RETURNING id,status,updated_at',[parsed.data.status,req.params.id]);
    if(!result.rowCount) return res.status(404).json({error:'Ride not found'});
    res.json(result.rows[0]);
  } catch(e){next(e);}
});

app.patch('/api/drivers/:id/availability', async (req,res,next) => {
  const parsed=z.object({isOnline:z.boolean()}).safeParse(req.body);
  if(!parsed.success) return res.status(400).json({error:'isOnline must be boolean'});
  if(process.env.NODE_ENV==='production') return res.status(501).json({error:'Driver auth middleware must be configured before availability changes'});
  try {
    const result=await pool.query('UPDATE driver_profiles SET is_online=$1, updated_at=now() WHERE user_id=$2 RETURNING user_id,is_online',[parsed.data.isOnline,req.params.id]);
    if(!result.rowCount) return res.status(404).json({error:'Driver not found'});
    res.json(result.rows[0]);
  } catch(e){next(e);}
});

app.use((err,_req,res,_next) => {
  console.error({message:err.message, name:err.name});
  res.status(500).json({error:'Internal server error'});
});
app.listen(port,()=>console.log(`GaonCab API listening on :${port}`));
